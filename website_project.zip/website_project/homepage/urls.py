from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    #path to registrarCultivo function at views
    path('registrarCultivo/', views.registrarCultivo),
    #path to modificarCultivo function at views
    path('modificarCultivo/', views.modificarCultivo),
    path('modificacion/', views.modificacion),
    #path to activarRiego function at views
    path('activarRiego/', views.activarRiego), #activarRiego/<nombre>
    #path to desactivarRiego function at views
    path('desactivarRiego/', views.desactivarRiego), #desactivarRiego/<nombre>
    #path to infoCultivo function at views
    path('infoCultivo/', views.infoCultivo)
]

