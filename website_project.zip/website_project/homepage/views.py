from django.shortcuts import render, redirect
from .models import Usuario, Cultivo

# Create your views here.

# HOME PAGE
def home(request):
    cultivosLista = Cultivo.objects.all()
    return render(request, 'homepage/home.html', {"cultivos": cultivosLista})

# REGISTER
def registrarCultivo(request):
    nombre = request.POST['txtNombre']
    tipo = request.POST['txtTipo']
    imagen = request.POST['imgFoto']
    
    cultivo = Cultivo.objects.create(nombre=nombre, tipo=tipo, imagen=imagen)
    return redirect('/')

# MODIFY 
def modificarCultivo(request):
    return render(request, "homepage/modCultivo.html")

def modificacion(request):
    nombre = request.POST['txtNombre']
    tipo = request.POST['txtTipo']
    imagen = request.POST['imgFoto']
    
    cultivo = Cultivo.objects.get(nombre=nombre)
    cultivo.nombre = nombre
    cultivo.tipo = tipo
    cultivo.imagen = imagen
    cultivo.save()
    
    return redirect('/')

# STATICS
def infoCultivo(request): #, nombre
    #cultivo = Cultivo.objects.get(nombre=nombre)
    return render(request, "homepage/statics.html")

# DELETE
def eliminarCultivo(request, nombre):
    cultivo = Cultivo.objects.get(nombre=nombre)
    cultivo.delete()
    return redirect('/')
        
        
#--THESE WILL ACTIVATE WATER FUNCTION WHEN DEVICE IS BUILT--

def activarRiego(request):
    #cultivo = Cultivo.objects.get(nombre=nombre)
    return render(request, "homepage/waterOn.html") # ,{"cultivo": cultivo}
    
def desactivarRiego(request):
    #cultivo = Cultivo.objects.get(nombre=nombre)
    return render(request, "homepage/waterOff.html") # ,{"cultivo": cultivo}


    """ 
    """